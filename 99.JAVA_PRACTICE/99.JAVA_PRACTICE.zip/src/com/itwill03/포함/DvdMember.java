package com.itwill03.포함;


public class DvdMember {
	/*
	- 캡슐화
	<<속성>>
	회원번호
	회원이름
	전화번호
	빌린dvd
	 */
	private Dvd rentDvd;//빌린dvd
	/*
	<<기능>>
	  회원정보출력 
	 */
}
