package com.itwill03.review;

public class AMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
