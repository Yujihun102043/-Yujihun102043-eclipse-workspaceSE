package com.itwill03.review;

public class MemberMethodMain {

	public static void main(String[] args) {
		
		/*
		 * MemberMethod객체생성
		 */
		
		/*
		 * MemberMethodr객체 method1 호출
		 */
		
		/*
		 * MemberMethodr객체 method2 호출
		 */
		/*
		 * MemberMethod객체 method3 호출
		 */
		/*
		 * MemberMethodr객체 method4 호출
		 */
		/*
		 * MemberMethodr객체 method5 호출
		 */
		
		
		
		
	}

}
