package com.itwill03.review;

public class MemberFieldMain {

	public static void main(String[] args) {
		/*
		 * 1.MemberField객체생성
		 */
		
		
		/*
		 * 2.MemberField객체의 멤버변수4개에 데이타대입
		 */
		
		
		/*
		 * 3.MemberField객체의 4개멤버변수내용출력
		 */
	}

}
