package com.itwill03.review;
/*
 * 1.객체를 생성할 클래스
 * 2.데이타타입
 */
public class MemberField {
	
	/*
	1. 멤버변수4개생성
	*/
	
}
